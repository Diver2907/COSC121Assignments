package A4;

public class Q3 {
    
}
